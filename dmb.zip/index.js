const Application = require("./src/server.js");
new Application();
