const CookieEnv = Object.freeze({
    BLOG_JWT: "blog_jwt",
})


module.exports = CookieEnv