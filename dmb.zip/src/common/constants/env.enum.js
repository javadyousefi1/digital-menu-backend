const NodeEnv = Object.freeze({
    Production: "production",
    Development: "developemnt"
})


module.exports = NodeEnv